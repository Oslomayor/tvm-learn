#include <cstdio>
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <tvm/runtime/module.h>
#include <tvm/runtime/registry.h>
#include <tvm/runtime/c_runtime_api.h>

#include <boost/type_index.hpp>
#define PRINT_TYPE(V) std::cout << boost::typeindex::type_id_with_cvr<decltype(V)>().pretty_name() << std::endl

int main(){
    tvm::runtime::Module mod_dylib = tvm::runtime::Module::LoadFromFile("model/model.so");

    std::ifstream json_in("model/graph.json");
    if (json_in.fail()){
        throw std::runtime_error("could not open json file");
    }

    std::ifstream params_in("model/params.params", std::ios::binary);
    if (params_in.fail()){
        throw std::runtime_error("could not open params file");
    }

    const std::string json_data((std::istreambuf_iterator<char>(json_in)), std::istreambuf_iterator<char>());
    json_in.close();
    const std::string params_data((std::istreambuf_iterator<char>(params_in)), std::istreambuf_iterator<char>());
    params_in.close();

    int dtype_code = kDLFloat;
    int dtype_bits = 32;
    int dtype_lanes = 1;
    int device_type = kDLExtDev;
    //int device_type = kDLCPU;
    int device_id = 0;

    tvm::runtime::Module mod = (*tvm::runtime::Registry::Get("tvm.graph_executor.create"))(json_data, mod_dylib, device_type, device_id);

    tvm::runtime::PackedFunc get_input = mod.GetFunction("get_input");
    assert(get_input != nullptr);
    tvm::runtime::PackedFunc load_params = mod.GetFunction("load_params");
    assert(load_params != nullptr);
    tvm::runtime::PackedFunc run = mod.GetFunction("run");
    assert(run != nullptr);
    tvm::runtime::PackedFunc get_output = mod.GetFunction("get_output");
    assert(get_output != nullptr);

#if 1
    int num_outputs = mod.GetFunction("get_num_outputs")();
    std::cout << "number of output = " << num_outputs << std::endl;
#endif

    // Load weights
    TVMByteArray params_arr;
    params_arr.data = params_data.c_str();
    params_arr.size = params_data.length();
    load_params(params_arr);

    // Load input
    DLTensor* x = get_input(0); // 0 is the input node index
    std::ifstream data_fin("img_data", std::ios::binary);
    size_t data_len = 3 * 224 * 224 * 4;
    char* data = (char*)malloc(data_len);
    data_fin.read(data, data_len);
    TVMArrayCopyFromBytes(x, data, data_len);
    free(data);

    printf("0x%lX\n", x);

    run();
    
    // allocate output
    DLTensor* y;
    int out_ndim = 2;
    int64_t out_shape[2] = {1, 1000};
    TVMArrayAlloc(out_shape, out_ndim, dtype_code, dtype_bits, dtype_lanes,
            kDLCPU, device_id, &y);
    get_output(0, y);
    printf("0x%lX\n", y);

    // get the maximum position in output vector
    auto y_iter = static_cast<float*>(y->data);
    auto max_iter = std::max_element(y_iter, y_iter + 1000);
    auto max_index = std::distance(y_iter, max_iter);
    std::cout << "The output should be 282" << std::endl;
    std::cout << "The maximum position in output vector is: " << max_index << std::endl;

    TVMArrayFree(x);
    TVMArrayFree(y);

    return 0;
}
